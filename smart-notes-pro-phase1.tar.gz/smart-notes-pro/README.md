# Smart Notes Pro
Phase 1 done: dashboard + notes management (www/). Run locally: `npm install && npm run serve`.
Android: push to GitHub; the Actions workflow builds a debug APK (artifact `smart-notes-pro-apk`).
Phases 2-7 (TipTap editor, links/tables/attachments, SQLite, Firebase, export/security, release APK) follow.
