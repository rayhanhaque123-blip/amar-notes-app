// Storage layer. Phase 1 uses localStorage; Phase 4 swaps this file for SQLite
// while keeping the same async API, so app.js does not change.
const DB = (() => {
  const K = 'snp.notes', F = 'snp.folders';
  const read = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } };
  const write = (k, v) => localStorage.setItem(k, JSON.stringify(v));
  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
  return {
    async notes() { return read(K, []); },
    async folders() { return read(F, []); },
    async saveNote(n) {
      const all = read(K, []), now = Date.now();
      const i = all.findIndex(x => x.id === n.id);
      if (i < 0) all.push({ id: uid(), title: '', body: '', folder: '', tags: [], favorite: false, archived: false, trashed: false, created: now, updated: now, synced: false, ...n });
      else all[i] = { ...all[i], ...n, updated: now, synced: false };
      write(K, all);
      return i < 0 ? all[all.length - 1] : all[i];
    },
    async deleteForever(id) { write(K, read(K, []).filter(n => n.id !== id)); },
    async addFolder(name) { const f = read(F, []); if (!f.includes(name)) f.push(name); write(F, f); },
    async removeFolder(name) {
      write(F, read(F, []).filter(x => x !== name));
      write(K, read(K, []).map(n => n.folder === name ? { ...n, folder: '' } : n));
    }
  };
})();
