const $ = id => document.getElementById(id);
const state = { view: 'all', folder: '', q: '', sort: 'updated', notes: [], folders: [] };
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const plain = h => { const d = document.createElement('div'); d.innerHTML = h; return d.textContent; };
const toast = m => { const t = $('toast'); t.textContent = m; t.classList.add('show'); setTimeout(() => t.classList.remove('show'), 1800); };

const VIEWS = [
  ['all', 'All notes', n => !n.trashed && !n.archived],
  ['recent', 'Recent notes', n => !n.trashed && !n.archived && Date.now() - n.updated < 7 * 864e5],
  ['fav', 'Favorites', n => n.favorite && !n.trashed],
  ['archive', 'Archived notes', n => n.archived && !n.trashed],
  ['trash', 'Trash', n => n.trashed],
  ['attach', 'Attachments', n => !n.trashed && (n.attachments || []).length > 0]
];

async function load() { state.notes = await DB.notes(); state.folders = await DB.folders(); render(); }

function filtered() {
  let v = VIEWS.find(x => x[0] === state.view);
  let list = state.view === 'folder' ? state.notes.filter(n => !n.trashed && n.folder === state.folder) : state.notes.filter(v[2]);
  const q = state.q.trim().toLowerCase();
  if (q) list = list.filter(n => (n.title + ' ' + plain(n.body) + ' ' + n.tags.join(' ')).toLowerCase().includes(q));
  const s = state.sort;
  return list.sort((a, b) => s === 'title' ? a.title.localeCompare(b.title) : b[s] - a[s]);
}

function render() {
  $('nav').innerHTML = VIEWS.map(([k, label, f]) =>
    `<button data-v="${k}" class="${state.view === k ? 'on' : ''}">${label}<small>${state.notes.filter(f).length}</small></button>`).join('') +
    `<div class="meta" style="padding:14px 12px 4px">Folders</div>` +
    state.folders.map(f => `<button data-f="${esc(f)}" class="${state.view === 'folder' && state.folder === f ? 'on' : ''}">${esc(f)}<small>${state.notes.filter(n => !n.trashed && n.folder === f).length}</small></button>`).join('') +
    `<button data-addf="1">+ New folder</button><button data-set="1">Settings</button>`;
  const title = state.view === 'folder' ? state.folder : VIEWS.find(x => x[0] === state.view)[1];
  $('viewTitle').textContent = title;
  $('bar').innerHTML = state.view === 'folder' ? `<button class="ghost danger" data-delf="1">Delete folder</button>` :
    state.view === 'trash' ? `<button class="ghost danger" data-empty="1">Empty trash</button>` : '';
  const list = filtered();
  $('list').innerHTML = list.length ? list.map(card).join('') :
    `<div class="empty">${state.q ? 'No notes match your search.' : state.view === 'trash' ? 'Trash is empty.' : 'No notes here yet. Select New note to start.'}</div>`;
}

function card(n) {
  const t = n.trashed;
  const btn = (a, l) => `<button data-a="${a}" data-id="${n.id}">${l}</button>`;
  return `<article class="note" data-open="${n.id}">
    <h3>${esc(n.title || 'Untitled')}</h3><p>${esc(plain(n.body)).slice(0, 160)}</p>
    <div class="tags">${n.tags.map(x => `<span>${esc(x)}</span>`).join('')}</div>
    <div class="meta">${new Date(n.updated).toLocaleString()}${n.folder ? ' · ' + esc(n.folder) : ''}</div>
    <div class="acts">${t ? btn('restore', 'Restore') + btn('purge', 'Delete forever') :
      btn('fav', n.favorite ? '★ Unfavorite' : '☆ Favorite') + btn('dup', 'Duplicate') + btn('move', 'Move') + btn('rename', 'Rename') +
      btn('arch', n.archived ? 'Unarchive' : 'Archive') + btn('trash', 'Trash')}</div></article>`;
}

function modal(html) { $('box').innerHTML = html; $('modal').classList.add('open'); }
const close = () => $('modal').classList.remove('open');
function ask(label, value = '') {
  return new Promise(res => {
    modal(`<label>${label}</label><input id="mi" value="${esc(value)}"><div class="row"><button class="ghost" id="mc">Cancel</button><button class="primary" id="mo">OK</button></div>`);
    $('mi').focus();
    $('mc').onclick = () => { close(); res(null); };
    $('mo').onclick = () => { const v = $('mi').value.trim(); close(); res(v || null); };
  });
}

function editor(n) {
  const isNew = !n;
  n = n || { title: '', body: '', tags: [], folder: state.view === 'folder' ? state.folder : '' };
  modal(`<input id="et" placeholder="Title" value="${esc(n.title)}">
    <textarea id="eb" placeholder="Write your note">${esc(plain(n.body))}</textarea>
    <input id="eg" placeholder="Tags, separated by commas" value="${esc(n.tags.join(', '))}">
    <div class="row"><span class="meta" id="es" style="flex:1;align-self:center">${isNew ? '' : 'Saved'}</span><button class="primary" id="ed">Done</button></div>`);
  let cur = n.id ? n : null, timer;
  const save = async () => {
    const title = $('et').value.trim(), body = $('eb').value;
    if (!cur && !title && !body) return;
    const tags = $('eg').value.split(',').map(s => s.trim()).filter(Boolean);
    cur = await DB.saveNote({ ...(cur ? { id: cur.id } : { folder: n.folder }), title, body: esc(body).replace(/\n/g, '<br>'), tags });
    $('es').textContent = 'Saved'; state.notes = await DB.notes(); render();
  };
  ['et', 'eb', 'eg'].forEach(i => $(i).oninput = () => { $('es').textContent = 'Saving…'; clearTimeout(timer); timer = setTimeout(save, 500); });
  $('ed').onclick = async () => { clearTimeout(timer); await save(); close(); };
}

async function act(a, id) {
  const n = state.notes.find(x => x.id === id), p = {};
  if (a === 'fav') p.favorite = !n.favorite;
  if (a === 'arch') { p.archived = !n.archived; toast(p.archived ? 'Archived' : 'Unarchived'); }
  if (a === 'trash') { p.trashed = true; toast('Moved to trash'); }
  if (a === 'restore') { p.trashed = false; toast('Restored'); }
  if (a === 'purge') { if (!confirm('Delete this note permanently?')) return; await DB.deleteForever(id); return load(); }
  if (a === 'dup') { const { id: _, ...c } = n; await DB.saveNote({ ...c, title: (n.title || 'Untitled') + ' (copy)', favorite: false }); toast('Duplicated'); return load(); }
  if (a === 'rename') { const t = await ask('Rename note', n.title); if (t === null) return; p.title = t; }
  if (a === 'move') {
    const f = await ask('Move to folder (new names are created)', n.folder); if (f === null) return;
    await DB.addFolder(f); p.folder = f;
  }
  await DB.saveNote({ id, ...p }); load();
}

document.addEventListener('click', async e => {
  const t = e.target;
  if (t.dataset.a) { e.stopPropagation(); return act(t.dataset.a, t.dataset.id); }
  if (t.dataset.v) { state.view = t.dataset.v; closeSide(); return render(); }
  if (t.dataset.f) { state.view = 'folder'; state.folder = t.dataset.f; closeSide(); return render(); }
  if (t.dataset.addf) { const f = await ask('Folder name'); if (f) { await DB.addFolder(f); load(); } return; }
  if (t.dataset.delf) { if (confirm('Delete folder? Notes move to All notes.')) { await DB.removeFolder(state.folder); state.view = 'all'; load(); } return; }
  if (t.dataset.empty) { if (confirm('Permanently delete all trashed notes?')) { for (const n of state.notes.filter(x => x.trashed)) await DB.deleteForever(n.id); load(); } return; }
  if (t.dataset.set) return modal(`<h3 style="margin:0">Settings</h3><p class="meta">Dark mode follows your device. Language, PIN lock and cloud sync arrive in later phases.</p><div class="row"><button class="primary" onclick="document.getElementById('modal').classList.remove('open')">Close</button></div>`);
  const c = t.closest('[data-open]'); if (c) return editor(state.notes.find(n => n.id === c.dataset.open));
  if (t === $('modal')) close();
});
const closeSide = () => { $('side').classList.remove('open'); $('scrim').classList.remove('open'); };
$('menuBtn').onclick = () => { $('side').classList.add('open'); $('scrim').classList.add('open'); };
$('scrim').onclick = closeSide;
$('newBtn').onclick = () => editor(null);
$('search').oninput = e => { state.q = e.target.value; render(); };
$('sort').onchange = e => { state.sort = e.target.value; render(); };
load();
