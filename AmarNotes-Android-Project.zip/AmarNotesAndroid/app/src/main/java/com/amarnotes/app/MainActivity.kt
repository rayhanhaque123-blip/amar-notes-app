package com.amarnotes.app

import android.app.Activity
import android.os.Bundle
import android.webkit.*
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import android.content.ContentValues
import java.io.OutputStreamWriter
import android.graphics.Color
import android.view.View
import android.view.WindowManager
import android.content.pm.ActivityInfo

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val fileRequest = 4102
    private val backupRequest = 4103
    private var pendingBackup: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        window.statusBarColor = Color.rgb(21, 94, 87)
        window.navigationBarColor = Color.rgb(10, 55, 49)
        window.decorView.systemUiVisibility = 0
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.setBackgroundColor(Color.rgb(243, 247, 246))
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.setSupportZoom(false)
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                }
                startActivityForResult(intent, fileRequest)
                return true
            }
        }
        web.addJavascriptInterface(BackupBridge(), "AndroidBackup")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class BackupBridge {
        @JavascriptInterface fun showMessage(message: String) {
            runOnUiThread { Toast.makeText(this@MainActivity, message, Toast.LENGTH_SHORT).show() }
        }
        @JavascriptInterface fun saveBackup(json: String) {
            runOnUiThread {
                pendingBackup = json
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                    putExtra(Intent.EXTRA_TITLE, "amar-notes-backup.json")
                }
                startActivityForResult(intent, backupRequest)
            }
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == fileRequest) {
            val result = if (resultCode == RESULT_OK && data?.data != null) arrayOf(data.data!!) else null
            fileCallback?.onReceiveValue(result)
            fileCallback = null
        } else if (requestCode == backupRequest) {
            val uri = data?.data
            val payload = pendingBackup
            if (resultCode == RESULT_OK && uri != null && payload != null) {
                try {
                    contentResolver.openOutputStream(uri)?.use { stream ->
                        OutputStreamWriter(stream, Charsets.UTF_8).use { it.write(payload) }
                    }
                    Toast.makeText(this, "ব্যাকআপ সংরক্ষণ হয়েছে", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "ব্যাকআপ সংরক্ষণ করা যায়নি", Toast.LENGTH_LONG).show()
                }
            }
            pendingBackup = null
        }
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
