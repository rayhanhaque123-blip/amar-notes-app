# আমার নোটস — Android APK প্রকল্প

এই প্রকল্পে আগের HTML নোটস অ্যাপটি Android WebView-এর মধ্যে চালানো হয়। নোট `localStorage`-এ এই অ্যাপের নিজস্ব ডেটায় সংরক্ষিত থাকে। অ্যাপ আনইনস্টল বা App data clear করলে ডেটা মুছে যেতে পারে—তাই নিয়মিত JSON ব্যাকআপ নিন।

## APK তৈরি (GitHub Actions দিয়ে)
1. এই ZIP ফাইলটি Extract করুন।
2. GitHub-এ নতুন একটি repository তৈরি করুন।
3. ZIP-এর ভেতরের সব ফাইল repository-তে upload/commit করুন (root-এ `app`, `build.gradle`, `.github` থাকবে)।
4. GitHub repository-র **Actions** ট্যাবে যান। `Build Amar Notes APK` workflow নির্বাচন করে **Run workflow** চাপুন।
5. Build শেষ হলে workflow run-এর নিচে **Artifacts** থেকে `Amar-Notes-APK` ডাউনলোড করুন।
6. ZIP extract করে `app-debug.apk` Android ফোনে পাঠিয়ে ইনস্টল করুন। প্রয়োজনে Android Settings-এ ওই উৎস থেকে app install করার অনুমতি দিন।

## Android Studio দিয়ে
Android Studio-তে এই ফোল্ডারটি Open করুন এবং Gradle Sync শেষে Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।

Package: `com.amarnotes.app` · Version: `1.0` · Minimum Android: 6.0
